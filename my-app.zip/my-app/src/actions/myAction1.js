export const updateName = (payload) => (
    {
        type: "UPDATE-NAME",
        payload
    }
);
