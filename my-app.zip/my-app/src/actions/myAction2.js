export const updateAddress = (payload) => (
    {
        type: "UPDATE-ADDRESS",
        payload
    }
);