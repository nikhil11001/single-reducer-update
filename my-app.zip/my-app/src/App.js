import React from 'react';
import {connect} from "react-redux";
import logo from './logo.svg';
import './App.css'
import { updateAddress } from './actions/myAction2';
import { updateName } from './actions/myAction1';

class App extends React.Component {
  render(){
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            <input type="text" 
            value={this.props.name} 
            onChange={(e)=>{this.props.updateName(e.target.value)}}/>
          </p>
          <p>
            <input type="text" 
            value={this.props.address}
            onChange={(e)=>{this.props.updateAddress(e.target.value)}}
           />
          </p>
          <p>
          </p>
        </header>
      </div>
    );
  }
  
}

const mapDispatchToProps=(dispatch)=>(
  {
    updateName:(name)=>(
      dispatch(updateName(name))
    ),

    updateAddress:(address)=>(
      dispatch(updateAddress(address))
    )
  }
);

const mapStateToProps=(state)=>{
  
    console.log(state)
    return {
      name:state.myReducer1.name,
      address:state.myReducer2.address,
    }
  
  
}
export default connect(mapStateToProps,mapDispatchToProps)(App);
