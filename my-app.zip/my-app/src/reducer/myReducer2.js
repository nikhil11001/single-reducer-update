let initialState = {
    address: "PUNE"
};

export default function myReducer2(state = initialState, action) {
    let newState = { ...state };
    switch (action.type) {
        case "UPDATE-ADDRESS":
            newState.address = action.payload;
    }
    return newState;
}

 