let initialState = {
    name: "NIKHIL"
};

export default function myReducer1(state = initialState, action) {
    let newState = { ...state };
    switch (action.type) {
        case "UPDATE-NAME":
            newState.name = action.payload;
    }
    return newState;
}
