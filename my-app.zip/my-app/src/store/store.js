import { createStore, combineReducers } from 'redux';
import { filterActions } from 'redux-ignore'; // Importe the library in Store
import myReducer1 from "../reducer/myReducer1";
import myReducer2 from "../reducer/myReducer2";

const rootReducer=combineReducers({
    //Pass filterActions method 2 parameters
    //filterActions(reducer namee, [array of action type releated to that reducers only])
    myReducer1:filterActions(myReducer1,["UPDATE-NAME"]),
    myReducer2:filterActions(myReducer2,["UPDATE-ADDRESS"]),
})

const store=createStore(rootReducer)
export default store;

